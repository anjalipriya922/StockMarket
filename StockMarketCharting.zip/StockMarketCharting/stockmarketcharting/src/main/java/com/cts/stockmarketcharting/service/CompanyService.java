package com.cts.stockmarketcharting.service;

import java.util.List;

import com.cts.stockmarketcharting.entity.Company;

public interface CompanyService {
  public Company findCompanyByName(String name);
  
  public List<Company> findAll();
  
  public void save(Company company);
  
  public void deactivate(Company company);
  
  public void updateCEO(Company company, String newCeo);
  
 
  }
